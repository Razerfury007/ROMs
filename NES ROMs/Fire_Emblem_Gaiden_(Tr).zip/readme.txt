        FIRE EMBLEM GAIDEN
      Unofficial Translation
       v.1.0  by Artemis251
------------------------------------

This is a simple IPS patch that correct's the level-up text on j2e's
previous attempts (and some minor fixes done by Starwolf) to translate
the game.




APPLICATION
-----------

Depending on your ROM version, you'll choose one of the three contained files:

1) FEG_Jap_to_251.ips --- for japanese-language ROMS.

2) FEG_j2e_to_251.ips --- for j2e's translation.

3) FEG_Starwofl_to_251.ips --- for Starwolf_UK's patch to j2e's translation that
      fixes the Ragnarok glitch. This is untested - I assume he didn't touch
      anything out of the range that j2e did.




PROBLEMS
--------

While translating, I found a few odd inconsistencies in the text. Some were just
odd; a good example is that getting Luck from a Lion Statue generated default text
for the word 'luck' instead of reading the argument for the attribute like every
other statue.

Thus, as much as I've tested this game, I may have missed other weird snippets.
If that's the case, drop me an E-mail at Artemis251@yahoo.com with the subject
"Fire Emblem Gaiden problem" and I'll try my best to fix it and get a new version
out. A screenshot would be nice, too, if you have it, and definitely a story on
how you got to the discrepancy.

As it is, there are definitely some weird issues in the game's code that are not
from translation. The game can randomly freeze at times for no apparent reason.
Probably the most known is the class-up graphic screw-up. If you class up at a
statue of Mila, the screen goes weird for a second and some random tiles are 
spewed onto the screen. This happens in the Japanese version as well (I tested
it), and I have no clue why it does that.

However, as far as I know, the game now works great and should provide those
curious in the game a good translation, based greatly on the hard work of
Shimizu Hitomi. I translated some of the smaller segments, but she's the one who
provided a full translation of the game's dialogue. I just tweaked it to fit in
the given text blocks.




SPECIAL THANKS
--------------

Shimizu Hitomi - She provided a translation of the game's dialogue and allowed me
                 to use it in this project.

j2e - I borrowed his font and modified it a bit. 

My beta testers - For helpin' this project move along!

--------------------------------------------


Thanks for downloading, and I hope this patch makes things a little easier to understand!
Enjoy the game!

